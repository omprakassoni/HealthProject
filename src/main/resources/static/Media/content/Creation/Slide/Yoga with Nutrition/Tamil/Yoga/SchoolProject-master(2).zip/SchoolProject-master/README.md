# SchoolProject
A Spring boot application

This is a initial version of the project.

