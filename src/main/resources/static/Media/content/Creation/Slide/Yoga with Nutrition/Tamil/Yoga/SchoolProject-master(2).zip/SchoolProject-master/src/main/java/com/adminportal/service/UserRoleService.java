package com.adminportal.service;

public interface UserRoleService {
	int countRow();

}
